package uk.gov.dwp.uc.pairtest;

import thirdparty.paymentgateway.TicketPaymentService;
import thirdparty.seatbooking.SeatReservationService;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest.Type;
import uk.gov.dwp.uc.pairtest.exception.InvalidPurchaseException;

public class TicketServiceImpl<ticketTypeRequests> implements TicketService {
	private int amount;
	private int seatno;
	int totalAmountToPay=0;
	int totalSeatsToAllocate=0;
	private int AmountToPay1p;
	private int SeatsToAllocate1p;
	private int methodtotalAmount;
	private int methodtotalSeats;
	private int totaltickets=0;
	Long accountId;
	private int children=0;
	private int adult=0;
	private boolean safetylock;

	/**
     * Should only have private methods other than the one below.
     */
	private TicketPaymentService ticketpaymentService;
	private SeatReservationService seatreservationService;
	
    @Override
    public void purchaseTickets(Long accountId, TicketTypeRequest... ticketTypeRequests) throws InvalidPurchaseException {
    	TicketTypeRequest[] t1 = ticketTypeRequests;
    	
    	   for(TicketTypeRequest t:t1) {
    		   totaltickets = totaltickets+t.getNoOfTickets();
    		   if(t.getTicketType()==Type.ADULT) {
          			adult=adult+1;
          		}else if(t.getTicketType()==Type.CHILD | t.getTicketType()==Type.INFANT ) {
          			children=children+1;
          		}
    	   }
    	   if(adult>0 && children==0) {
       			safetylock=true;
       		}else if(adult>0 && children>0) {
       			safetylock=true;
       		}else if(adult==0 && children>0) {
       			safetylock=false;
       		}
           if(accountId>0 && totaltickets<=20 && safetylock==true) {
        	   for(TicketTypeRequest t:t1) {
        		   {
        			   AmountToPay1p= totalAmount(t.getNoOfTickets(),t.getTicketType());
        			   SeatsToAllocate1p = totalSeats(t.getNoOfTickets(),t.getTicketType());
        		   }
        		   totalAmountToPay = totalAmountToPay+AmountToPay1p;
        		   totalSeatsToAllocate = totalSeatsToAllocate+SeatsToAllocate1p;
        	   }
        	   }
           ticketpaymentService.makePayment(accountId,totalAmountToPay);
           seatreservationService.reserveSeat(accountId, totalSeatsToAllocate);
    }
    
    private int totalAmount(int nooftickets,Type ticketype) {
    	if(ticketype==Type.ADULT) {
    		amount= 20;
    	}else if(ticketype==Type.CHILD) {
    		amount= 10;
    	}else if(ticketype==Type.INFANT) {
    		amount= 0;
    	}
    	methodtotalAmount = nooftickets*amount;
    	
    	return methodtotalAmount;
    }
    
    private int totalSeats(int nooftickets,Type ticketype) {
    	if(ticketype==Type.ADULT) {
    		seatno=1;
    	}else if(ticketype==Type.CHILD) {
    		seatno=1;
    	}else if(ticketype==Type.INFANT) {
    		seatno=0;
    	}
    	methodtotalSeats= nooftickets*seatno;
		return methodtotalSeats;

}
}